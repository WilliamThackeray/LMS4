// // For utility functions used often

// exports.utils = () => {

//   utils.getQueryString(options) {

//   }

//   utils.getItemIndex(data, id) {
//     const index = data.findIndex( item => parseInt(item.id) === parseInt(id))
//     return index
//   }
// }