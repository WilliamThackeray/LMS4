const Lookup = function(lookup) {
  
}