//lookup.routes.js
//no controller here, just made the sql call here to simplify.
//Implemented Teams as well for later when we have a player form
//Example call:   /lookups/coaches

module.exports = app => {
  const lookups = require('../models/lookup.model.js')

  // app.get('/lookups/:lookupTable', lookups.look)
}